// this sets the background color of the master UIView (when there are no windows/tab groups on it)

//require('/modules/_').create().open();

var MODEL = require('/modules/model');
var ui = require('/modules/ui').create(new MODEL);
